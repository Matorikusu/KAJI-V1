const { contextBridge } = require("electron");
contextBridge.exposeInMainWorld("kaji", { forged: true });
