@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo North needs Node.js the first time it launches.
  echo Get it from https://nodejs.org then double-click Start.bat again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Preparing North...
  call npm install --no-fund --no-audit
)
npx --yes electron .
