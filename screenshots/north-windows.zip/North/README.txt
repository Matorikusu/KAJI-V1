North
Forged by Kaji for Windows.

Double-click Start.bat.
The first launch prepares the runtime. After that, it opens like any other app.

Window 1280×800
React (Vite) · TypeScript
